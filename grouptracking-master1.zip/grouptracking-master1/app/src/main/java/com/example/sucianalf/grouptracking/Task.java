package com.example.sucianalf.grouptracking;

public class Task {

    private String task;
    public Task() {}

    public void setTask(String task) {
        this.task = task;
    }

    public Task(String task) {
        this.task = task;
    }
    public String getTask() {
        return task;
    }
}
