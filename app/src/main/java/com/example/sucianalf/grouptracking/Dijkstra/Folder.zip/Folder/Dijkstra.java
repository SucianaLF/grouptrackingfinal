package com.example.sucianalf.grouptracking.Dijkstra;

public class Dijkstra {
	   private static final Graph.Edge[] GRAPH = {
	      new Graph.Edge("a", "b", 8),
	      new Graph.Edge("b", "c", 2),
	      new Graph.Edge("c", "d", 5),
	      new Graph.Edge("d", "e", 2),
	      new Graph.Edge("e", "f", 13),
	      new Graph.Edge("f", "g", 2),
	      new Graph.Edge("g", "h", 5),
//	      new Graph.Edge("d", "i", 1),
//	      new Graph.Edge("d", "g", 3),
//		  new Graph.Edge("e", "g", 1),
//		  new Graph.Edge("f", "g", 2),
//		  new Graph.Edge("f", "h", 3),
//		  new Graph.Edge("g", "h", 6),
//		  new Graph.Edge("g", "f", 2),
	   };
	   private static final String START = "a";
	   private static final String END = "h";
	 
	   public static void main(String[] args) {
	      Graph g = new Graph(GRAPH);
	      g.dijkstra(START);
	      g.printPath(END);
	   }
	}

